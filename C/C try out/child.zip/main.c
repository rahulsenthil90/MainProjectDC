/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c,d,e,f,g,h,i,j,k,l;
    scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
    f=(a>20)?1:0;
    g=(b>20)?1:0;
    h=(c>20)?1:0;
    i=(d>20)?1:0;
    j=(e>20)?1:0;
    k=f+g+h+i+j;
    l=5-k;
    printf("adult: %d\n",k);
    printf("child: %d",l);
    return 0;
}
