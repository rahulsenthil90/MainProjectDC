/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    char a[50];
    int i,j,n,f=1;
    scanf("%[^\n]",a);
    for(i=0;a[i];i++){
        if(a[i]>96)
        a[i]=0;
        else
        a[i]=1;
    }
     n=a[i-1];
     for(j=i;j>0;j--){
         if(n==a[i])
         printf("no");
     }
      for(j=i;j>0;j--){
         if(1>=a[i])
         printf("no");
     }
     }
   /* for(j=i;j>0;j--){
        if(a[j-1]>=a[j]){
        f=0;}
        
        
    }
    printf(f?"yes":"no");*/
    return 0;
}
