/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    printf("Hello \n World \n");
    printf("Hello \r World\n");
    printf("Hello \b World\n");
    printf("Hello \v World\n");
    printf("Hello \t World\n");
    printf("Hello \f World\n");

    return 0;
}

