/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,a,x=0;
    scanf("%d",&n);
    while(n){
        n--;
        scanf("%d",&a);
        if(x<a)
        x=a;
    }
    printf("\n %d is the greatest number",x);
    return 0;
}
