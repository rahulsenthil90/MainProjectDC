/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,a[50],even=0,odd=0,i,t,j;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        if(a[i]%2==0)
        even++;
        else
        odd++;
    }
    if(odd>even)
    {
        for(i=0;i<n;i++)
        {
            if(a[i]%2!=0)
                for(j=i+1;j<n;j++)
                    if(a[j]%2!=0)
                        if(a[i]>a[j])
                        {
                            t=a[i];
                            a[i]=a[j];
                            a[j]=t;
                        }
        }
    }
    else
    {
        for(i=0;i<n;i++)
        {
            if(a[i]%2==0)
                for(j=i+1;j<n;j++)
                    if(a[j]%2==0)
                        if(a[i]>a[j])
                        {
                            t=a[i];
                            a[i]=a[j];
                            a[j]=t;
                        }
        }
    }
    for(i=0;i<n;i++)
    printf("%d",a[i]);
    return 0;
}
