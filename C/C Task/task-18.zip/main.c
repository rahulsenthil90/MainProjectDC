/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int  l(int n)
{
    if(n==0)
    return 2;
    else if(n==1)
    return 1;
    else
    return l(n-1)+l(n-2);
}
int main()
{
    int n;
    scanf("%d",&n);
    printf("%d",l(n));
    return 0;
}
