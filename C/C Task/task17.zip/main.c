/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int sqr(int h)
{

    float n,r;
    n=h/2;
    while(r!=n)
    {
        r=n;
        n=(((h/r)+r)/2);
    }
    return n;
}
int rev(int n)
{
    int r=0;
    while(n)
    {
        r=r*10+n%10;
        n/=10;
    }
    return r;
}
int main()
{
    int a,t;
    scanf("%d",&a);
    t=a;
    a*=a;
    a=rev(a);
    a=sqr(a);
    a=rev(a);
    if(t=a)
    printf("adam");
    else
    printf("not adam");
}


