/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
struct student{
    char st[50];
    int m1,m2,m3,total;
    
}s[100];
int main()
{
    int i,j,r=1,sa;
    scanf("%d",&sa);
    for(i=1;i<=sa;i++){
        scanf("%s%d%d%d",s[i].st,&s[i].m1,&s[i].m2,&s[i].m3);
        s[i].total=s[i].m1+s[i].m2+s[i].m3;}
        for(i=1;i<=sa;i++){
            for(j=1,r=1;j<=sa;j++){
                if(s[i].total<s[j].total)
                r++;
            }
            printf("name: %s total: %d rank: %d \n",s[i].st,s[i].total,r);
        }
    return 0;
}




