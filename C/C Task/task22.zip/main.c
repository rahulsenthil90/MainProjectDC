/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{
    char a[100],b[10][10],f[50],re[50];
    int i,r=0,c=0;
    scanf("%[^\n]%s%s",a,f,re);
    for(i=0;a[i];i++)
    {
        if(a[i]!=' ')
        {
            b[r][c]=a[i];
            c++;
        }
        else
        {
            b[r][c]='\0';
            r++;
            c=0;
        }
    }
    for(i=0;i<=r;i++)
    {
        if(strcmp(b[i],f)==0){
        strcpy(b[i],re);}
        printf("%s ",b[i]);
    }

    return 0;
}
