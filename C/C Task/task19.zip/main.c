/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int b[100],c[100],n,i,j;
    scanf("%d",&n);
    for(i=0;i<n;i++){
    scanf("%d",&b[i]);
    c[i]=b[i];
    }
    for(i=0;i<n;i++)
    for(j=i+1;j<n;j++)
    if(b[i]==c[j])
    c[j]=c[j]/2;
    
    for(i=0;i<n;i++)
    if(b[i]==c[i])
    printf("%d ",b[i]);
    return 0;
}
