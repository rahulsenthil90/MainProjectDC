/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char a[100];
    int i,f=1;
    scanf("%[^\n]",a);
    for(i=0;a[i];i++)
        if(a[i]==',')
        if(a[i-1]!=a[i+1]){
            f=0;
            break;
        }
        if(a[0]!=a[i-1])
        f=0;
    printf("%d",f);
    return 0;
}

