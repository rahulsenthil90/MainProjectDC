
#include <stdio.h>
#include <string.h>
int main()
{
    FILE *fp;
    char a[50],b[30][30],f[50],re[30];
    int i,r=0,c=0;
    fp=fopen("file.txt","r");
    fscanf(fp,"%[^\n]",a);
    fclose(fp);
    
    printf("%s\n",a);
    scanf("%s%s",f,re);
    for(i=0;a[i];i++){
        if(a[i]==' ')
        {
            b[r][c]=0;
            r++;
            c=0;
        }
        else
        {
            b[r][c]=a[i];
            c++;
        }
    }
    b[r][c]=0;
    fp=fopen("file.txt","a");
    for(i=0;i<=r;i++){
        if(!strcmp(b[i],f))
        strcpy(b[i],re);
        fprintf(fp,"%s",b[i]);
        printf("%s ",b[i]);
    }
    fclose(fp);
    return 0;
}
