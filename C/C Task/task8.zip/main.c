#include <stdio.h>

int main()
{
    int a;
    float n,r;
    scanf("%d",&a);
    n=a/2;
    while(r!=n)
    {
        r=n;
        n=(((a/r)+r)/2);
        printf("%f %f\n",n,r);
    }
    printf("%.3f",n);
    return 0;
}