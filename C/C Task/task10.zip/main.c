/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,r=10,f=0,g;
    scanf("%d",&a);
    while(a)
    {
        b=a%10;
        if(r>=b)
        g=1;
        else
        f=1;
        r=b;
        a/=10;
    }
    printf(f?"not progresive":"progressive");
    return 0;
}

