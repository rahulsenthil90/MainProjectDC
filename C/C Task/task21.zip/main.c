/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
   int i,j,r,c,a[10][10],sum=0;
   scanf("%d",&r);
   for(i=1;i<=r;i++)
    for(j=1;j<=r;j++)
    scanf("%d",&a[i][j]);
    for(i=1;i<=r;i++)
     for(j=1;j<=r;j++)
     if(j==i||j+i==r+1)
     sum+=a[i][j];
     printf("%d",sum);
    return 0;
}
