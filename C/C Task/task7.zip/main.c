/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,t,f=0,r=0;
    scanf("%d",&a);
    t=a;
    while(a)
    {
        if(a%10!=3)
        r=r*10+a%10;
        else
        f=1;
        a/=10;
    }
    printf("%d",f==1?r:t);
    return 0;
}
