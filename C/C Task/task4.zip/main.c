/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
int a;
scanf("%d",&a);
if(a>0&&a<101)
    {
            switch((a-1)/10)
            {
                case 0:
                case 1:
                case 2:
                case 3:
                printf("D");
                break;
                case 4:
                case 5:
                printf("A");
                break;
                case 6:
                case 7:
                printf("B");
                break;
                case 8:
                case 9:
                printf("Fail");
                break;
            }
    } 
    else
    printf("invalid");
return 0;
}



