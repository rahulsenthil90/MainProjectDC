/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i=1,a=-1,b=1,t;
    scanf("%d",&n);
    while(i<=n)
    {
    t=a+b;
    printf("%d ",t);
    a=b;
    b=t;
    i++;
    }

    return 0;
}
