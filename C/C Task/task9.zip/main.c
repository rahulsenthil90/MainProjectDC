/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,t,f,c=0,sum=0;
    scanf("%d",&a);
    t=a;
    while(a)
    {
        c++;
        a/=10;
    }
    if(c%2)
    {
        while(t)
        {
            f=t%10;
            sum=sum+f;
            t=t/100;
        }
    }
    else
    {
        while(t)
        {
            t/=10;
            f=t%10;
            sum+=f;
            t/=10;
        }
    }
    printf("%d",sum);
    return 0;
}
