/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int count(int a)
{
    int c=0;
    while(a)
    {
        c++;
        a=a/10;
    }
    return c;
}
int power(int b,int p){
    int z=1;
    while(p--)
    {
        z*=b;
    }
    return z;
}
int main()
{
    int n,d,sum=0,c=0;
    scanf("%d",&n);
    d=n;
    c=count(n);
    while(n){
        sum+=power(n%10,c);
        n/=10;
    }
    if(d==sum)
    printf("armstrong number");
    else
    printf("not armstrong number");
    return 0;
}


