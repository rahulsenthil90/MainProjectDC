#include <stdio.h>
void sor(int*,int);
int main()
{
   int s[100],n,i;
   scanf("%d",&n);
   for(i=0;i<n;i++)
   scanf("%d",&s[i]);
   sor(s,n); 
   for(i=0;i<n;i++)
   printf("%d ",s[i]);
   return 0;
}
void sor(int *x,int y)
{
    int i,j,t;
    for(i=0;i<y;i++)
        for(j=i+1;j<y;j++)
        if(*(x+i)>*(x+j)){
            t=*(x+i);
            *(x+i)=*(x+j);
            *(x+j)=t;
        }
}


